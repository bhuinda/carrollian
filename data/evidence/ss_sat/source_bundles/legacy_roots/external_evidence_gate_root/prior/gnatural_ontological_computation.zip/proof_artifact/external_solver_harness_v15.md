# Proof Artifact: External Solver Harness v15

V15 turns the previous in-package proof-log tests into an external ingestion protocol.

\[
	ext{external solver/proof log}	o	ext{canonical events}	o D_{20}	ext{ route}	o\Sigma_{\le5}.
\]

## Sandbox probe

- SAT solver binaries found: 0
- DRAT/LRAT proof tools found: 0
- Third-party logs ingested: 0
- Canary fixture ingestion: PASS

## Interpretation

The package is now ready for genuine external solver evidence, but this run does not contain it. The scientifically relevant next step is to supply actual solver stdout/proof files from CaDiCaL, Kissat, MiniSat, CryptoMiniSat, or a DRAT/LRAT verifier pipeline and rerun the adapter.
