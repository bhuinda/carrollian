# G^natural Ontological Computation v14

## Scope

V14 builds the first proof-certificate ingestion layer. It does **not** ingest third-party DRAT/LRAT files from external solvers. Instead it generates small UNSAT CNF instances, derives resolution certificates to the empty clause, renders LRAT-like, DRAT-like, and CSV proof dialects, validates the parent-resolution proof chain, and maps the resulting proof logs into ordered route signatures through class 5.

The finite base remains \(G^
atural=A_{985}\), and the public domain remains \(D_{20}=\Lambda^3H_6\).

## Proof audit

| invariant | value |
|---|---:|
| UNSAT benchmark instances | 7 |
| rendered proof traces | 7 |
| proof dialects | 3 |
| validated empty-clause proofs | 7/7 |
| semantic presentation-invariance groups | 0/0 |
| route presentation-invariance groups | 0/0 |

All three proof dialects are rendered, but v14-fast analyzes one canonical LRAT-like route per proof. Presentation-invariance rows are therefore not used in this pass.

## All proof logs: ordered-route ranks

| field | deg3 | deg4 | deg5 | deg4 increment | deg5 increment |
|---|---:|---:|---:|---:|---:|
| F2 | 7 | 7 | 7 | 0 | 0 |
| F3 | 7 | 7 | 7 | 0 | 0 |
| F5 | 7 | 7 | 7 | 0 | 0 |

## Main result

The proof-log layer also satisfies the class-3 ceiling in this bounded internally generated proof-certificate battery:

\[
\operatorname{rank}(\Sigma_{\le5})=\operatorname{rank}(\Sigma_{\le3}).
\]

This extends the ceiling from solver execution telemetry to proof-certificate telemetry. It is still not third-party solver evidence.

## Next target

Feed genuine external proof certificates, especially DRAT/LRAT files emitted by CaDiCaL/Kissat-style solvers, through the v14 proof schema.
