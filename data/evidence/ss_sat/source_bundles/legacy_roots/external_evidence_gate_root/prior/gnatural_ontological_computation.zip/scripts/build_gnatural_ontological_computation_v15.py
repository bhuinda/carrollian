#!/usr/bin/env python3
from __future__ import annotations
import csv, json, hashlib, shutil, os, subprocess, textwrap, itertools, time
from pathlib import Path

ROOT=Path('/mnt/data/gnatural_ontological_computation_v15')
ZIP=Path('/mnt/data/gnatural_ontological_computation_v15.zip')
D20_JSON=Path('/mnt/data/d20.json')
V14_ROOT=Path('/mnt/data/gnatural_ontological_computation_v14')
V14_ZIP=Path('/mnt/data/gnatural_ontological_computation_v14.zip')

SOLVERS=['minisat','cadical','kissat','glucose','cryptominisat','lingeling']
PROOF_TOOLS=['drat-trim','lrat-check','gratgen','gratgen-native','drat2lrat','cake_lpr']

# ---------------- utilities ----------------
def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

def write_csv(path:Path, rows, fieldnames=None):
    rows=list(rows); path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames=list(rows[0].keys()) if rows else []
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(rows)

def command_exists(cmd):
    from shutil import which
    p=which(cmd)
    return p

def try_version(cmd):
    for args in ([cmd,'--version'],[cmd,'-h'],[cmd,'--help']):
        try:
            r=subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=3)
            out=(r.stdout or '').strip().splitlines()
            return r.returncode, (out[0][:160] if out else '')
        except Exception as e:
            last=str(e)
    return None, last

# ---------------- benchmarks ----------------
def clean_clause(cl):
    s=set(cl)
    if any(-x in s for x in s): return None
    return frozenset(s)

def write_dimacs(path,nvars,clauses):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        f.write(f'c GNATURAL v15 benchmark fixture\n')
        f.write(f'p cnf {nvars} {len(clauses)}\n')
        for c in clauses:
            f.write(' '.join(map(str,sorted(c,key=lambda x:(abs(x),x))))+' 0\n')

def contradiction(n=4):
    clauses=[frozenset([1]), frozenset([-1])]
    for i in range(2,n+1): clauses.append(frozenset([i,-i+1]))
    return n,clauses

def horn_chain(n=8):
    clauses=[frozenset([1])]
    for i in range(1,n): clauses.append(frozenset([-i,i+1]))
    clauses.append(frozenset([-n]))
    return n,clauses

def php(p,h):
    def x(i,j): return 1+i*h+j
    clauses=[]
    for i in range(p): clauses.append(frozenset([x(i,j) for j in range(h)]))
    for i in range(p):
        for a in range(h):
            for b in range(a+1,h): clauses.append(frozenset([-x(i,a),-x(i,b)]))
    for j in range(h):
        for a in range(p):
            for b in range(a+1,p): clauses.append(frozenset([-x(a,j),-x(b,j)]))
    return p*h,clauses

def xor_clause(vars,par):
    out=[]
    for bits in itertools.product([0,1], repeat=len(vars)):
        if sum(bits)%2 != par:
            out.append(frozenset([-v if b else v for v,b in zip(vars,bits)]))
    return out

def xor_unsat():
    clauses=[]
    clauses += xor_clause([1,2,3],1)
    clauses += xor_clause([3,4,5],0)
    clauses += xor_clause([1,2,4,5],1)
    clauses += xor_clause([1,2,4,5],0)
    return 5,clauses

# ---------------- scripts ----------------
RUN_EXTERNAL_SCRIPT=r'''#!/usr/bin/env python3
"""Run external SAT solvers on benchmark DIMACS files and collect proof/log files.

This script is intentionally conservative. It does not assume a solver is installed.
Supported examples:
  python run_external_solvers.py --solver cadical --cnf benchmarks/horn_chain_8.cnf --out external_runs
  python run_external_solvers.py --solver kissat  --cnf benchmarks/php_3_2.cnf --out external_runs

For proof-producing modes, pass --proof-out if your solver supports it. The exact flags vary by solver.
"""
from __future__ import annotations
import argparse, subprocess, shutil, json, time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--solver', required=True)
    ap.add_argument('--cnf', required=True)
    ap.add_argument('--out', default='external_runs')
    ap.add_argument('--proof-out', default=None)
    ap.add_argument('--extra', nargs='*', default=[])
    args=ap.parse_args()
    solver_path=shutil.which(args.solver)
    if not solver_path:
        raise SystemExit(f'solver not found on PATH: {args.solver}')
    cnf=Path(args.cnf)
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    stem=f'{cnf.stem}_{args.solver}_{int(time.time())}'
    stdout_path=out/f'{stem}.stdout.txt'
    stderr_path=out/f'{stem}.stderr.txt'
    proof_path=Path(args.proof_out) if args.proof_out else out/f'{stem}.proof'
    cmd=[solver_path]+args.extra+[str(cnf)]
    # Users may include proof flags in --extra, for example: --extra --proof external_runs/foo.drat
    t0=time.time()
    proc=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    dt=time.time()-t0
    stdout_path.write_text(proc.stdout or '', encoding='utf-8')
    stderr_path.write_text(proc.stderr or '', encoding='utf-8')
    meta={'solver':args.solver,'solver_path':solver_path,'cnf':str(cnf),'cmd':cmd,'returncode':proc.returncode,'seconds':dt,'stdout':str(stdout_path),'stderr':str(stderr_path),'proof_hint':str(proof_path)}
    (out/f'{stem}.meta.json').write_text(json.dumps(meta,indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps(meta,indent=2))
if __name__=='__main__': main()
'''

INGEST_SCRIPT=r'''#!/usr/bin/env python3
"""Ingest external solver/proof logs into the G^natural v15 event schema.

Accepts:
  - JSON event arrays following schema/solver_trace.schema.json
  - DRAT-like proof lines: [d] lit ... 0
  - LRAT-like proof lines: id lit ... 0 ...
  - solver stdout lines containing keywords: restart/conflict/decision/propagate/learn

This adapter produces canonical_events.json and a stable semantic hash. The full D20 route
signature computation is performed by the package builder; this adapter is designed for local use
when third-party logs are supplied later.
"""
from __future__ import annotations
import argparse, json, hashlib, re
from pathlib import Path

def stable_hash(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def event(t, **kw):
    d={'type':t}; d.update(kw); return d

def parse_file(path:Path):
    text=path.read_text(errors='replace')
    if path.suffix.lower()=='.json':
        obj=json.loads(text)
        if isinstance(obj,dict) and 'events' in obj: return obj['events']
        if isinstance(obj,list): return obj
    events=[]
    for ln,line in enumerate(text.splitlines(),1):
        s=line.strip()
        if not s or s.startswith('c'): continue
        low=s.lower()
        if any(k in low for k in ['restart','conflict','decision','decide','propagate','learn','clause']):
            typ='COMMENT'
            if 'restart' in low: typ='RESTART'
            elif 'conflict' in low: typ='CONFLICT'
            elif 'decision' in low or 'decide' in low: typ='DECIDE'
            elif 'propagate' in low: typ='PROPAGATE'
            elif 'learn' in low: typ='LEARN'
            nums=[int(x) for x in re.findall(r'-?\d+', s)]
            events.append(event(typ,line=ln,size=len(nums),lit_sum=sum(nums),abs_sum=sum(abs(x) for x in nums)))
            continue
        # DRAT add/delete: optional d then literals until 0
        toks=s.split()
        if toks[0]=='d':
            lits=[int(x) for x in toks[1:] if re.match(r'-?\d+$',x) and int(x)!=0]
            events.append(event('DELETE',line=ln,size=len(lits),lit_sum=sum(lits),abs_sum=sum(abs(x) for x in lits),pos_count=sum(1 for x in lits if x>0),neg_count=sum(1 for x in lits if x<0)))
        elif all(re.match(r'-?\d+$',x) for x in toks[:min(len(toks),8)]):
            nums=[int(x) for x in toks if re.match(r'-?\d+$',x)]
            # LRAT-like begins with id; DRAT-like begins directly with clause. Use first token as id if there are two zeros or ':' absent not tracked.
            lits=[]
            start=1 if len(nums)>2 and nums[0]>0 and 0 in nums[1:] else 0
            for x in nums[start:]:
                if x==0: break
                lits.append(x)
            typ='EMPTY' if len(lits)==0 else 'ADD'
            events.append(event(typ,line=ln,id=nums[0] if start else ln,size=len(lits),lit_sum=sum(lits),abs_sum=sum(abs(x) for x in lits),pos_count=sum(1 for x in lits if x>0),neg_count=sum(1 for x in lits if x<0)))
    return events

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('paths', nargs='+')
    ap.add_argument('--out', default='canonical_events.json')
    args=ap.parse_args()
    all_events=[]
    for p in args.paths:
        ev=parse_file(Path(p))
        all_events.append({'source':p,'events':ev,'semantic_hash':stable_hash(ev)})
    Path(args.out).write_text(json.dumps({'schema':'gnatural.external_events.v15','sources':all_events},indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps({'out':args.out,'sources':len(all_events),'event_counts':[len(x['events']) for x in all_events],'hashes':[x['semantic_hash'] for x in all_events]},indent=2))
if __name__=='__main__': main()
'''

SCHEMA_JSON={
  '$schema':'https://json-schema.org/draft/2020-12/schema',
  'title':'Gnatural external solver/proof trace event schema v15',
  'type':'object',
  'required':['schema','sources'],
  'properties':{
    'schema':{'const':'gnatural.external_events.v15'},
    'sources':{'type':'array','items':{'type':'object','required':['source','events','semantic_hash'],'properties':{'source':{'type':'string'},'semantic_hash':{'type':'string'},'events':{'type':'array','items':{'type':'object','required':['type'],'properties':{'type':{'type':'string'},'line':{'type':'integer'},'id':{'type':'integer'},'size':{'type':'integer'},'pivot':{'type':'integer'},'lit_sum':{'type':'integer'},'abs_sum':{'type':'integer'},'pos_count':{'type':'integer'},'neg_count':{'type':'integer'}}}}}}}
  }
}


def main():
    if ROOT.exists(): shutil.rmtree(ROOT)
    for sub in ['tables','scripts','schema','benchmarks','adapters','fixtures','external_runs','prior','proof_artifact']:
        (ROOT/sub).mkdir(parents=True, exist_ok=True)

    # Probe installed tools.
    probe_rows=[]
    for name in SOLVERS+PROOF_TOOLS:
        path=command_exists(name)
        rc,ver=try_version(name) if path else (None,'')
        probe_rows.append({'tool':name,'kind':'solver' if name in SOLVERS else 'proof_tool','found':bool(path),'path':path or '', 'version_probe_returncode':rc if rc is not None else '', 'version_probe_head':ver})
    write_csv(ROOT/'tables'/'external_tool_probe.csv',probe_rows)

    # Benchmarks.
    benches=[]
    families=[('contradiction_4',)+contradiction(4), ('horn_chain_8',)+horn_chain(8), ('horn_chain_12',)+horn_chain(12), ('php_3_2',)+php(3,2), ('xor_unsat',)+xor_unsat()]
    for name,nvars,clauses in families:
        p=ROOT/'benchmarks'/f'{name}.cnf'
        write_dimacs(p,nvars,clauses)
        benches.append({'benchmark':name,'nvars':nvars,'clauses':len(clauses),'path':str(p.relative_to(ROOT)),'sha256':sha256_file(p)})
    write_csv(ROOT/'tables'/'benchmark_manifest.csv',benches)

    # Copy prior v14 certificate and summarize if available.
    v14_cert={}
    if (V14_ROOT/'certificate.json').exists():
        v14_cert=json.loads((V14_ROOT/'certificate.json').read_text())
        shutil.copy2(V14_ROOT/'certificate.json',ROOT/'prior'/'v14_certificate.json')
    if (V14_ROOT/'report.md').exists(): shutil.copy2(V14_ROOT/'report.md',ROOT/'prior'/'v14_report.md')
    if V14_ZIP.exists():
        # don't copy bulky if not needed? include hash in cert.
        pass

    # Write scripts/adapters.
    (ROOT/'adapters'/'run_external_solvers.py').write_text(RUN_EXTERNAL_SCRIPT,encoding='utf-8')
    (ROOT/'adapters'/'ingest_external_logs.py').write_text(INGEST_SCRIPT,encoding='utf-8')
    os.chmod(ROOT/'adapters'/'run_external_solvers.py',0o755)
    os.chmod(ROOT/'adapters'/'ingest_external_logs.py',0o755)
    (ROOT/'schema'/'external_solver_trace.schema.json').write_text(json.dumps(SCHEMA_JSON,indent=2,sort_keys=True),encoding='utf-8')

    # Create canary fixture logs representing accepted formats.
    fixture_lines={
        'minisat_style.stdout.txt':'c benchmark canary\ns SATISFIABLE\nc conflicts 12 decisions 8 propagations 44 restarts 2\n',
        'cadical_style.stdout.txt':'c canary\nc restarting after 12 conflicts\nc decision 3 propagate 19 learn 4\ns UNSATISFIABLE\n',
        'drat_like.proof':'c canary DRAT\n1 0\nd 1 0\n0\n',
        'lrat_like.proof':'1 1 0 0\n2 -1 0 0\n3 0 1 2 0\n'
    }
    fixture_rows=[]
    for fn,txt in fixture_lines.items():
        p=ROOT/'fixtures'/fn; p.write_text(txt,encoding='utf-8')
        fixture_rows.append({'fixture':fn,'path':str(p.relative_to(ROOT)),'sha256':sha256_file(p),'bytes':p.stat().st_size})
    write_csv(ROOT/'tables'/'fixture_manifest.csv',fixture_rows)

    # Run adapter on fixtures to create canonical event file.
    adapter_out=ROOT/'fixtures'/'canary_canonical_events.json'
    cmd=['python3',str(ROOT/'adapters'/'ingest_external_logs.py')]+[str(ROOT/'fixtures'/fn) for fn in fixture_lines]+['--out',str(adapter_out)]
    proc=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
    canary_ok=proc.returncode==0 and adapter_out.exists()
    canary_summary=json.loads(adapter_out.read_text()) if canary_ok else {'sources':[]}
    canary_rows=[]
    for s in canary_summary.get('sources',[]):
        canary_rows.append({'source':s['source'],'events':len(s['events']),'semantic_hash':s['semantic_hash']})
    write_csv(ROOT/'tables'/'canary_ingestion_summary.csv',canary_rows)

    # Read v14 class ranks for carry-forward.
    v14_all={}
    try:
        v14_all=v14_cert.get('all_proof_log_signature_summary',{})
    except Exception:
        v14_all={}
    carry_rows=[]
    for p in [2,3,5]:
        carry_rows.append({
            'field':f'F{p}',
            'v14_deg3_rank':v14_all.get(f'combined_deg3_rank_F{p}',''),
            'v14_deg4_rank':v14_all.get(f'combined_deg4_rank_F{p}',''),
            'v14_deg5_rank':v14_all.get(f'combined_deg5_rank_F{p}',''),
            'class3_ceiling': v14_all.get(f'combined_deg3_rank_F{p}','') == v14_all.get(f'combined_deg5_rank_F{p}','') if v14_all else ''
        })
    write_csv(ROOT/'tables'/'v14_class_ceiling_carry_forward.csv',carry_rows)

    solver_found=sum(1 for r in probe_rows if r['kind']=='solver' and r['found'])
    proof_found=sum(1 for r in probe_rows if r['kind']=='proof_tool' and r['found'])
    readiness_status='EXTERNAL_SOLVER_BINARY_FOUND' if solver_found else 'NO_EXTERNAL_SOLVER_BINARY_FOUND_IN_SANDBOX'
    proof_status='EXTERNAL_PROOF_TOOL_FOUND' if proof_found else 'NO_EXTERNAL_PROOF_TOOL_FOUND_IN_SANDBOX'
    readiness=[
        {'component':'solver_binary_probe','status':readiness_status,'count':solver_found,'notes':'Checked common solver executable names on PATH.'},
        {'component':'proof_tool_probe','status':proof_status,'count':proof_found,'notes':'Checked common DRAT/LRAT verifier/converter names on PATH.'},
        {'component':'external_run_harness','status':'READY','count':2,'notes':'run_external_solvers.py and ingest_external_logs.py are included.'},
        {'component':'benchmark_suite','status':'READY','count':len(benches),'notes':'Small UNSAT DIMACS fixtures included.'},
        {'component':'canary_ingestion','status':'PASS' if canary_ok else 'FAIL','count':len(canary_rows),'notes':'Adapter successfully parsed included fixture formats.'},
        {'component':'third_party_log_evidence','status':'PENDING','count':0,'notes':'No genuine third-party solver/proof logs were available in the sandbox.'},
    ]
    write_csv(ROOT/'tables'/'external_readiness_summary.csv',readiness)

    report=f"""# G^natural Ontological Computation v15

## Scope

V15 builds the external solver/proof-log bridge. It probes the sandbox for third-party SAT solvers and DRAT/LRAT tools, adds runnable adapters, adds a small DIMACS benchmark suite, and certifies canary ingestion for solver stdout, DRAT-like, and LRAT-like inputs.

It does **not** claim third-party solver evidence yet: no common external solver binary or proof verifier was found on this sandbox PATH during the probe.

The finite base remains \(G^\natural=A_{{985}}\), and the public domain remains \(D_{{20}}=\Lambda^3H_6\).

## External tool probe

| item | result |
|---|---:|
| solver binaries found | {solver_found} |
| proof tools found | {proof_found} |
| benchmarks included | {len(benches)} |
| canary fixture formats parsed | {len(canary_rows)} |

## Status

\[
\boxed{{\text{{third-party solver/proof ingestion is harness-ready but evidence-pending}}}}
\]

V14's internally generated proof-certificate layer is carried forward as the last completed proof-log invariant. The v15 contribution is the external reproducibility interface needed to ingest genuine MiniSat/CaDiCaL/Kissat-style solver logs or DRAT/LRAT proof files when supplied.

## How to run locally

```bash
cd gnatural_ontological_computation_v15
python3 adapters/run_external_solvers.py --solver cadical --cnf benchmarks/horn_chain_8.cnf --out external_runs
python3 adapters/ingest_external_logs.py external_runs/*.stdout.txt external_runs/*.proof --out external_runs/canonical_events.json
```

If a solver emits DRAT/LRAT files, pass those files directly to `ingest_external_logs.py`.
"""
    (ROOT/'report.md').write_text(report,encoding='utf-8')

    proof_artifact=f"""# Proof Artifact: External Solver Harness v15

V15 turns the previous in-package proof-log tests into an external ingestion protocol.

\[
\text{{external solver/proof log}}\to\text{{canonical events}}\to D_{{20}}\text{{ route}}\to\Sigma_{{\le5}}.
\]

## Sandbox probe

- SAT solver binaries found: {solver_found}
- DRAT/LRAT proof tools found: {proof_found}
- Third-party logs ingested: 0
- Canary fixture ingestion: {'PASS' if canary_ok else 'FAIL'}

## Interpretation

The package is now ready for genuine external solver evidence, but this run does not contain it. The scientifically relevant next step is to supply actual solver stdout/proof files from CaDiCaL, Kissat, MiniSat, CryptoMiniSat, or a DRAT/LRAT verifier pipeline and rerun the adapter.
"""
    (ROOT/'proof_artifact'/'external_solver_harness_v15.md').write_text(proof_artifact,encoding='utf-8')

    # Ledger
    ledger=[]
    if (V14_ROOT/'running_ledger.csv').exists():
        with (V14_ROOT/'running_ledger.csv').open(encoding='utf-8') as f:
            for r in csv.DictReader(f):
                r['package']='v14_imported'; ledger.append(r)
    def add(layer,inv,val,status,src): ledger.append({'package':'v15','layer':layer,'invariant':inv,'value':val,'status':status,'source':src})
    add('external_harness','solver_binaries_found',solver_found,readiness_status,'external_tool_probe.csv')
    add('external_harness','proof_tools_found',proof_found,proof_status,'external_tool_probe.csv')
    add('external_harness','benchmarks_included',len(benches),'READY','benchmark_manifest.csv')
    add('external_harness','canary_sources_parsed',len(canary_rows),'PASS' if canary_ok else 'FAIL','canary_ingestion_summary.csv')
    add('external_harness','third_party_logs_ingested',0,'PENDING','external_readiness_summary.csv')
    write_csv(ROOT/'running_ledger.csv',ledger)

    cert={
        'schema':'gnatural.ontological_computation.cert.v15',
        'status':'GNATURAL_ONTOLOGICAL_COMPUTATION_V15_EXTERNAL_HARNESS_READY_EVIDENCE_PENDING',
        'scope_warning':'No genuine third-party solver/proof logs are ingested in v15; no common external solver binaries were found in the sandbox probe.',
        'tool_probe':{'solver_binaries_found':solver_found,'proof_tools_found':proof_found,'rows':probe_rows},
        'benchmarks':benches,
        'canary_ingestion':{'pass':canary_ok,'sources':canary_rows,'adapter_stdout':proc.stdout,'adapter_stderr':proc.stderr},
        'v14_carry_forward':v14_all,
        'source_hashes':{'d20.json':sha256_file(D20_JSON),'v14_zip':sha256_file(V14_ZIP) if V14_ZIP.exists() else None}
    }
    (ROOT/'certificate.json').write_text(json.dumps(cert,indent=2,sort_keys=True),encoding='utf-8')

    shutil.copy2(Path(__file__), ROOT/'scripts'/'build_gnatural_ontological_computation_v15.py')
    # manifest and zip
    manifest=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file(): manifest.append({'file':str(p.relative_to(ROOT)).replace('\\','/'),'size':p.stat().st_size,'sha256':sha256_file(p)})
    write_csv(ROOT/'manifest.csv',manifest)
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if ZIP.exists(): ZIP.unlink()
    shutil.make_archive(str(ZIP.with_suffix('')),'zip',ROOT)
    print(json.dumps({'status':cert['status'],'zip':str(ZIP),'solver_binaries_found':solver_found,'proof_tools_found':proof_found,'canary_sources_parsed':len(canary_rows)},indent=2))

if __name__=='__main__': main()
