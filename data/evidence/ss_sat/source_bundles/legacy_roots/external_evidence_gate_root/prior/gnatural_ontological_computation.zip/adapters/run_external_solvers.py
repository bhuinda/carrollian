#!/usr/bin/env python3
"""Run external SAT solvers on benchmark DIMACS files and collect proof/log files.

This script is intentionally conservative. It does not assume a solver is installed.
Supported examples:
  python run_external_solvers.py --solver cadical --cnf benchmarks/horn_chain_8.cnf --out external_runs
  python run_external_solvers.py --solver kissat  --cnf benchmarks/php_3_2.cnf --out external_runs

For proof-producing modes, pass --proof-out if your solver supports it. The exact flags vary by solver.
"""
from __future__ import annotations
import argparse, subprocess, shutil, json, time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--solver', required=True)
    ap.add_argument('--cnf', required=True)
    ap.add_argument('--out', default='external_runs')
    ap.add_argument('--proof-out', default=None)
    ap.add_argument('--extra', nargs='*', default=[])
    args=ap.parse_args()
    solver_path=shutil.which(args.solver)
    if not solver_path:
        raise SystemExit(f'solver not found on PATH: {args.solver}')
    cnf=Path(args.cnf)
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    stem=f'{cnf.stem}_{args.solver}_{int(time.time())}'
    stdout_path=out/f'{stem}.stdout.txt'
    stderr_path=out/f'{stem}.stderr.txt'
    proof_path=Path(args.proof_out) if args.proof_out else out/f'{stem}.proof'
    cmd=[solver_path]+args.extra+[str(cnf)]
    # Users may include proof flags in --extra, for example: --extra --proof external_runs/foo.drat
    t0=time.time()
    proc=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    dt=time.time()-t0
    stdout_path.write_text(proc.stdout or '', encoding='utf-8')
    stderr_path.write_text(proc.stderr or '', encoding='utf-8')
    meta={'solver':args.solver,'solver_path':solver_path,'cnf':str(cnf),'cmd':cmd,'returncode':proc.returncode,'seconds':dt,'stdout':str(stdout_path),'stderr':str(stderr_path),'proof_hint':str(proof_path)}
    (out/f'{stem}.meta.json').write_text(json.dumps(meta,indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps(meta,indent=2))
if __name__=='__main__': main()
