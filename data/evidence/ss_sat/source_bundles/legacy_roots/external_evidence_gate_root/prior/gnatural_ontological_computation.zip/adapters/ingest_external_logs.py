#!/usr/bin/env python3
"""Ingest external solver/proof logs into the G^natural v15 event schema.

Accepts:
  - JSON event arrays following schema/solver_trace.schema.json
  - DRAT-like proof lines: [d] lit ... 0
  - LRAT-like proof lines: id lit ... 0 ...
  - solver stdout lines containing keywords: restart/conflict/decision/propagate/learn

This adapter produces canonical_events.json and a stable semantic hash. The full D20 route
signature computation is performed by the package builder; this adapter is designed for local use
when third-party logs are supplied later.
"""
from __future__ import annotations
import argparse, json, hashlib, re
from pathlib import Path

def stable_hash(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def event(t, **kw):
    d={'type':t}; d.update(kw); return d

def parse_file(path:Path):
    text=path.read_text(errors='replace')
    if path.suffix.lower()=='.json':
        obj=json.loads(text)
        if isinstance(obj,dict) and 'events' in obj: return obj['events']
        if isinstance(obj,list): return obj
    events=[]
    for ln,line in enumerate(text.splitlines(),1):
        s=line.strip()
        if not s or s.startswith('c'): continue
        low=s.lower()
        if any(k in low for k in ['restart','conflict','decision','decide','propagate','learn','clause']):
            typ='COMMENT'
            if 'restart' in low: typ='RESTART'
            elif 'conflict' in low: typ='CONFLICT'
            elif 'decision' in low or 'decide' in low: typ='DECIDE'
            elif 'propagate' in low: typ='PROPAGATE'
            elif 'learn' in low: typ='LEARN'
            nums=[int(x) for x in re.findall(r'-?\d+', s)]
            events.append(event(typ,line=ln,size=len(nums),lit_sum=sum(nums),abs_sum=sum(abs(x) for x in nums)))
            continue
        # DRAT add/delete: optional d then literals until 0
        toks=s.split()
        if toks[0]=='d':
            lits=[int(x) for x in toks[1:] if re.match(r'-?\d+$',x) and int(x)!=0]
            events.append(event('DELETE',line=ln,size=len(lits),lit_sum=sum(lits),abs_sum=sum(abs(x) for x in lits),pos_count=sum(1 for x in lits if x>0),neg_count=sum(1 for x in lits if x<0)))
        elif all(re.match(r'-?\d+$',x) for x in toks[:min(len(toks),8)]):
            nums=[int(x) for x in toks if re.match(r'-?\d+$',x)]
            # LRAT-like begins with id; DRAT-like begins directly with clause. Use first token as id if there are two zeros or ':' absent not tracked.
            lits=[]
            start=1 if len(nums)>2 and nums[0]>0 and 0 in nums[1:] else 0
            for x in nums[start:]:
                if x==0: break
                lits.append(x)
            typ='EMPTY' if len(lits)==0 else 'ADD'
            events.append(event(typ,line=ln,id=nums[0] if start else ln,size=len(lits),lit_sum=sum(lits),abs_sum=sum(abs(x) for x in lits),pos_count=sum(1 for x in lits if x>0),neg_count=sum(1 for x in lits if x<0)))
    return events

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('paths', nargs='+')
    ap.add_argument('--out', default='canonical_events.json')
    args=ap.parse_args()
    all_events=[]
    for p in args.paths:
        ev=parse_file(Path(p))
        all_events.append({'source':p,'events':ev,'semantic_hash':stable_hash(ev)})
    Path(args.out).write_text(json.dumps({'schema':'gnatural.external_events.v15','sources':all_events},indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps({'out':args.out,'sources':len(all_events),'event_counts':[len(x['events']) for x in all_events],'hashes':[x['semantic_hash'] for x in all_events]},indent=2))
if __name__=='__main__': main()
